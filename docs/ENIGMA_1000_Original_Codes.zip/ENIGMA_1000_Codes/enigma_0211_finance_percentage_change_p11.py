#!/usr/bin/env python3
"""ENIGMA code 0211/1000 — finance_percentage_change, preset 11/20.

Original local-only public source; no network/mining, no automatic crypto transfers.
This is one of 50 algorithms x 20 parameter settings, NOT 1,000 unique algorithms.
"""
import base64
import collections
import csv
import hashlib
import io
import json
import math
import re
import sys
import urllib.parse

B1_BTC_MAINNET = 'bc1qvprle87txnk7dgcgsau0nauxvvkwuyp0w9zc0z'
B2_BTC_MAINNET = 'bc1qtaunz7mx7k588p8v544tq7x7ezxxcfky0h2vn9'
B1_NATIVE_BASE_USDC_RECEIVE_ONLY = '0x734989a439F146885C12907cd9Dd191b03d5B07e'
# Addresses are displayed for optional, independently verified paid-service payment.
# This code neither mines Bitcoin nor uses these destinations automatically.
PRESET = 11
OPERATION = 'finance_percentage_change'
CODE_ID = 211

def run(v):
    a=[float(x) for x in v]
    return round((a[1]-a[0])/abs(a[0])*100,min(PRESET,10)) if len(a)>=2 and a[0]!=0 else None

def main():
    try:
        payload = json.load(sys.stdin)
        value = payload.get('value',payload) if isinstance(payload,dict) else payload
        result = run(value)
        print(json.dumps({'program_id':CODE_ID, 'operation':OPERATION, 'preset':PRESET, 'result':result},ensure_ascii=False,allow_nan=False))
    except Exception as exc:
        print(json.dumps({'program_id':CODE_ID,'error':str(exc)}),file=sys.stderr)
        sys.exit(1)

if __name__=='__main__':
    main()
