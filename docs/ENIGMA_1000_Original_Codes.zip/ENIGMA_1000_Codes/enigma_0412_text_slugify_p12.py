#!/usr/bin/env python3
"""ENIGMA code 0412/1000 — text_slugify, preset 12/20.

Original local-only public source; no network/mining, no automatic crypto transfers.
This is one of 50 algorithms x 20 parameter settings, NOT 1,000 unique algorithms.
"""
import base64
import collections
import csv
import hashlib
import io
import json
import math
import re
import sys
import urllib.parse

B1_BTC_MAINNET = 'bc1qvprle87txnk7dgcgsau0nauxvvkwuyp0w9zc0z'
B2_BTC_MAINNET = 'bc1qtaunz7mx7k588p8v544tq7x7ezxxcfky0h2vn9'
B1_NATIVE_BASE_USDC_RECEIVE_ONLY = '0x734989a439F146885C12907cd9Dd191b03d5B07e'
# Addresses are displayed for optional, independently verified paid-service payment.
# This code neither mines Bitcoin nor uses these destinations automatically.
PRESET = 12
OPERATION = 'text_slugify'
CODE_ID = 412

def run(v):
    s=str(v).strip().lower()
    s=re.sub(r'[^a-z0-9]+','-',s).strip('-')
    return s[:PRESET*8]

def main():
    try:
        payload = json.load(sys.stdin)
        value = payload.get('value',payload) if isinstance(payload,dict) else payload
        result = run(value)
        print(json.dumps({'program_id':CODE_ID, 'operation':OPERATION, 'preset':PRESET, 'result':result},ensure_ascii=False,allow_nan=False))
    except Exception as exc:
        print(json.dumps({'program_id':CODE_ID,'error':str(exc)}),file=sys.stderr)
        sys.exit(1)

if __name__=='__main__':
    main()
